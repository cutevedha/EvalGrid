"""
governance/pipeline.py: The 6-step governed evaluation pipeline.

What is governance in AI evaluation?
-------------------------------------
Production AI systems need more than a pass/fail score: they need an auditable
record that proves the evaluation was conducted honestly and that results can be
trusted.  The GovernancePipeline enforces that.

The 6 steps
-----------
1. **Validate inputs + dataset provenance**
   Hash the dataset to detect tampering.  Check for duplicate samples and
   prompt-injection attacks embedded in the evaluation inputs.

2. **Run the model under test UNCHANGED**
   Capture the raw output from the target system.  The pipeline never modifies
   what the model says: it only observes and records.

3. **Score with versioned metrics/judges**
   Compute scores using the Orchestrator.  Partial/malformed outputs are
   automatically downgraded to FAILED: they cannot pass by mistake.

4. **Log everything for audit and replay**
   Every action is appended to an AuditLog with a timestamp.  The full log is
   returned in GovernanceOutcome.audit so it can be stored and replayed later.

5. **Compare against fixed thresholds and build the report**
   Acceptance gates check whether the average metric scores meet pre-set
   minimums.  The report includes confidence intervals, not just point estimates.

6. **Block or flag on integrity / confidence failure**
   Red-flag checks look for scope violations, version mismatches, and
   non-reproducible scoring.  If any gate fails or red flags are found,
   the pipeline sets blocked=True so the caller can halt a release.

Decoupled design
----------------
The pipeline is wired through two plain callables:
  - runner(sample) -> str       Your target system (called unchanged).
  - scorer(sample, output) -> ScoreResult    Your metrics (via Orchestrator).

This means you can swap in any AI system or scoring strategy without touching
the governance logic.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from governance.audit import AuditLog, new_run_id
from governance.scope_control import EvalObjective, ScopeGuard
from governance.data_integrity import DatasetSnapshot, integrity_report
from governance.robustness import scan_eval_inputs_for_injection
from governance.scoring_rules import assert_deterministic
from governance.operational import is_scorable_pass
from governance.reporting import RunManifest, build_governance_report
from governance.acceptance import AcceptancePolicy
from governance.red_flags import scan_red_flags, is_clean, RedFlag


# Signatures for the pluggable pieces (kept simple and sync for clarity).
RunnerFn = Callable[[Dict[str, Any]], str]                      # sample -> output (target, unchanged)
ScorerFn = Callable[[Dict[str, Any], str], "ScoreResult"]      # (sample, output) -> ScoreResult


@dataclass
class ScoreResult:
    passed: bool
    scores: Dict[str, float]
    notes: List[str] = field(default_factory=list)


@dataclass
class GovernanceOutcome:
    run_id: str
    dataset_version: str
    report: Dict[str, Any]
    acceptance: Dict[str, Any]
    red_flags: List[RedFlag]
    blocked: bool
    audit: List[Dict[str, Any]]


class GovernancePipeline:
    """Runs the 6-step governed evaluation and returns a GovernanceOutcome."""

    def __init__(self, objective: EvalObjective, acceptance: AcceptancePolicy,
                 model_name: str = "unknown", audit: Optional[AuditLog] = None):
        self.objective = objective
        self.acceptance = acceptance
        self.model_name = model_name
        self.audit = audit or AuditLog(run_id=new_run_id())
        self.scope = ScopeGuard(self.audit)

    def run(
        self,
        samples: List[Dict[str, Any]],
        runner: RunnerFn,
        scorer: ScorerFn,
        judge_reference_leaks: int = 0,
        prompt_version: str = "n/a",
        judge_version: str = "n/a",
    ) -> GovernanceOutcome:
        """Execute all 6 governance steps and return an auditable outcome."""
        snapshot = self._step_validate(samples)
        outputs = self._step_run_model(samples, runner)
        results, meta = self._step_score(samples, outputs, scorer)
        self._step_audit_scores(results)
        acceptance_result, report = self._step_compare(
            samples, results, meta, snapshot, prompt_version, judge_version
        )
        flags, blocked = self._step_gate(
            results, _metric_means(results), acceptance_result,
            snapshot, judge_reference_leaks
        )
        self.audit.record("gate", blocked=blocked,
                          red_flags=[f.code for f in flags],
                          accepted=acceptance_result["accepted"])
        return GovernanceOutcome(
            run_id=self.audit.run_id,
            dataset_version=snapshot.version_id,
            report=report,
            acceptance=acceptance_result,
            red_flags=flags,
            blocked=blocked,
            audit=self.audit.to_list(),
        )

    # ── Private step methods ────────────────────────────────────────────

    def _step_validate(self, samples: List[Dict[str, Any]]) -> "DatasetSnapshot":
        """Step 1: validate dataset provenance and scan for prompt injection."""
        self.objective.validate()
        snapshot = DatasetSnapshot(name=self.objective.suite, samples=samples)
        integrity = integrity_report(samples)
        injection_flags = scan_eval_inputs_for_injection(samples)
        self.audit.record("validate", dataset_version=snapshot.version_id,
                          duplicates=integrity["exact_duplicate_count"],
                          injected_inputs=injection_flags)
        return snapshot

    def _step_run_model(
        self, samples: List[Dict[str, Any]], runner: RunnerFn
    ) -> Dict[str, str]:
        """Step 2: drive the target unchanged and capture raw outputs keyed by sample id."""
        outputs: Dict[str, str] = {}
        for idx, sample in enumerate(samples):
            sid = str(sample.get("id", f"idx{idx}"))
            output = runner(sample)          # target produces output
            self.scope.capture(sid, output)  # fingerprint, do not modify
            outputs[sid] = output
        return outputs

    def _step_score(
        self,
        samples: List[Dict[str, Any]],
        outputs: Dict[str, str],
        scorer: ScorerFn,
    ) -> tuple:
        """Step 3: score each output; downgrade partial/malformed outputs so they cannot pass."""
        results: List[Dict[str, Any]] = []
        meta: Dict[str, Dict[str, Any]] = {}
        for idx, sample in enumerate(samples):
            sid = str(sample.get("id", f"idx{idx}"))
            output = outputs[sid]
            score_result = scorer(sample, output)
            passed = is_scorable_pass(output, score_result.passed)
            notes = list(score_result.notes)
            if passed != score_result.passed:
                notes.append("downgraded: output missing/malformed cannot pass")
            results.append({"test_id": sid, "passed": passed,
                             "scores": score_result.scores, "notes": notes})
            meta[sid] = {
                "severity": sample.get("severity", "unknown"),
                "capability": sample.get("capability", "unknown"),
            }
        return results, meta

    def _step_audit_scores(self, results: List[Dict[str, Any]]) -> None:
        """Step 4: append a scored event to the audit log."""
        self.audit.record("scored", n=len(results),
                          passed=sum(1 for r in results if r["passed"]))

    def _step_compare(
        self,
        samples: List[Dict[str, Any]],
        results: List[Dict[str, Any]],
        meta: Dict[str, Dict[str, Any]],
        snapshot: "DatasetSnapshot",
        prompt_version: str,
        judge_version: str,
    ) -> tuple:
        """Step 5: run acceptance gates and assemble the governed report."""
        metric_means = _metric_means(results)
        acceptance_result = self.acceptance.evaluate(
            metric_means, len(results), confidence_ok=True
        )
        manifest = RunManifest(
            run_id=self.audit.run_id, model=self.model_name,
            dataset_version=snapshot.version_id, prompt_version=prompt_version,
            judge_version=judge_version, objective=self.objective.objective,
        )
        report = build_governance_report(manifest, results, meta=meta,
                                         expected_total=len(samples))
        return acceptance_result, report

    def _step_gate(
        self,
        results: List[Dict[str, Any]],
        metric_means: Dict[str, float],
        acceptance_result: Dict[str, Any],
        snapshot: "DatasetSnapshot",
        judge_reference_leaks: int,
    ) -> tuple:
        """Step 6: scan for red flags and decide whether to block the release."""
        reproducible = assert_deterministic(lambda: round(sum(metric_means.values()), 6))
        flags = scan_red_flags({
            "scope_violations": len(self.audit.events("scope.violation")),
            "prompts_modified": False,               # pipeline never modifies the target
            "judge_reference_leaks": judge_reference_leaks,
            "version_mismatch": not snapshot.verify(),
            "report_has_error_bars": True,           # report always carries a CI
            "report_has_failures": any(not r["passed"] for r in results),
            "scoring_reproducible": reproducible,
        })
        blocked = (not acceptance_result["accepted"]) or (not is_clean(flags))
        return flags, blocked


# ============================================================================
# HELPERS
# ============================================================================

def _metric_means(results: List[Dict[str, Any]]) -> Dict[str, float]:
    """Average each metric across all results (the input to acceptance gates)."""
    totals: Dict[str, float] = {}
    counts: Dict[str, int] = {}
    for r in results:
        for name, value in r.get("scores", {}).items():
            if isinstance(value, (int, float)):
                totals[name] = totals.get(name, 0.0) + value
                counts[name] = counts.get(name, 0) + 1
    return {m: totals[m] / counts[m] for m in totals}
